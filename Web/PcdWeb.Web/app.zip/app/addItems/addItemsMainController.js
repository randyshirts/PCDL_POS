﻿'use strict';
app.controller('addItemsMainController', ['$scope', function ($scope) {

}]);