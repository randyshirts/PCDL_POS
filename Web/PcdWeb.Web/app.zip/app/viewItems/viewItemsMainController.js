﻿'use strict';
app.controller('viewItemsMainController', ['$scope', function ($scope) {

}]);