﻿'use strict';
app.controller('signupChoiceController', ['$scope', function ($scope) {

}]);