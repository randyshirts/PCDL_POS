﻿'use strict';
app.controller('emailSentController', ['$scope', function ($scope) {

}]);