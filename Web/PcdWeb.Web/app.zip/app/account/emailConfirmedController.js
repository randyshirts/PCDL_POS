﻿'use strict';
app.controller('emailConfirmedController', ['$scope', function ($scope) {

}]);